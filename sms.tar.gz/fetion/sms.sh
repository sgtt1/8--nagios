#!/bin/bash
# script name : sms
# qq: 277057817
# url:www.nginxs.com
cd /usr/local/nagios/libexec
if [ $# -ne 5 ];then
	        phone="$1"
	        passwd="$2"
	        msg="$3"
	        sendto="$4"
		/usr/bin/python /opt/fetion/fetion.py "$phone" "$passwd" "$msg" "$sendto"
fi
